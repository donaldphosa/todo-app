import { initializeApp } from "firebase/app";
import { getAuth } from 'firebase/auth'
import {getFirestore} from '@firebase/firestore'

const firebaseConfig = {
    apiKey: "AIzaSyDRvRJxmPeOr0HIGO0v0K4S0Z1VIy_MwOs",
    authDomain: "todo-app-c51ab.firebaseapp.com",
    projectId: "todo-app-c51ab",
    storageBucket: "todo-app-c51ab.appspot.com",
    messagingSenderId: "962432978481",
    appId: "1:962432978481:web:30030d0a920309209a0f10"
  };
  

  const app = initializeApp(firebaseConfig);
 export const auth = getAuth(app)
 export const db = getFirestore(app)