import React,{useState, useEffect} from 'react';
import {signOut} from 'firebase/auth'
import {auth, db} from './firebase'
import { useNavigate } from 'react-router-dom';
import {collection, getDocs, addDoc, updateDoc, doc} from 'firebase/firestore'




function Home() {
  const [tasks, setTasks] = useState([]);
  const [taskName, setTasksName] = useState('');
  const [tasksDesc, setTasksDesc] = useState('');
  const taskref = collection(db,"items");
  const [tab,setTab] = useState("currenTtasks");
 
const id = JSON.parse(localStorage.getItem("id"))

//adding a task to our database
  const addtask = async()=>{
    await addDoc(taskref, {taskName:taskName, tasksdesc:tasksDesc, userid:id, status:"current"})
  }
  //updating the status of a task
  const updateStatus = async (id, status)=>{
    const taskdoc = doc(db,"items", id);
    const newField = {status:"completed"};
    await updateDoc(taskdoc,newField);
  }

  useEffect(()=>{
    //pulling data from firebase
    const getTask = async()=>{
      const data = await getDocs(taskref);
      setTasks(data.docs.map((doc)=>({...doc.data(), id:doc.id})))
     
    }
 

    getTask();
  },[])

     const navigate = useNavigate()
    const logout = async() =>{
        await signOut(auth);
        console.log(auth.currentUser);
        navigate("/")
    }
   
  return (
    <div >
      <button>Tasks</button>
      <button>Add tasks</button>
      
   { tab==="currenTtasks" && <CurrentItem task={tasks}
        updateStatus={updateStatus}
      />}
  { tab==="addtasks"  && <AddTask 
        addtask={addtask} 
        setTasksName={setTasksName}
        setTasksDesc={setTasksDesc}
        
      />}
     <button onClick={logout}>logout</button>
    </div>
  )
}

const CurrentItem = ({task,updateStatus})=>{
    return(<>
        {task&&task.map((tak,index)=>{return<div key={index}>
          <h1>{tak.taskName}</h1>
          <h1>{tak.tasksdesc}</h1>
          <h1>status: {tak.status}</h1>
          <button onClick={()=>updateStatus(tak.id,tak.status)}>complete</button>
        </div>})}
        </>
    )
}

const AddTask= ({addtask,setTasksDesc,setTasksName})=>{
    return(
        <div>
          <input placeholder='item title' onChange={(e)=>{setTasksName(e.target.value)}}/>
          <input placeholder='item desc' onChange={(e)=>{setTasksDesc(e.target.value)}}/>
        
          <button onClick={addtask}>Add task</button>
        </div>
    )
}

export default Home